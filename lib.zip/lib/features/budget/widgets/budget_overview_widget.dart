import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/liquid_card.dart';

class BudgetOverviewWidget extends StatelessWidget {
  final double totalIncome;
  final double totalBudget;
  final double totalSpent;
  final String currency;

  const BudgetOverviewWidget({
    super.key,
    required this.totalIncome,
    required this.totalBudget,
    required this.totalSpent,
    required this.currency,
  });

  @override
  Widget build(BuildContext context) {
    final remainingBudget = totalBudget - totalSpent;
    final budgetUsagePercentage =
        totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;

    return LiquidCard(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withOpacity(0.25),
          Colors.white.withOpacity(0.15),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Budget Overview',
              style: TextStyle(
                fontSize: 20.sp,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              )),
          SizedBox(height: 20.h),
          // Use Wrap for responsiveness
          Wrap(
            spacing: 24.w,
            runSpacing: 16.h,
            alignment: WrapAlignment.spaceEvenly,
            children: [
              _buildStatItem(
                  'Total Income',
                  '$currency ${NumberFormat('#,##0').format(totalIncome)}',
                  Colors.greenAccent),
              _buildStatItem(
                  'Total Budget Created',
                  '$currency ${NumberFormat('#,##0').format(totalBudget)}',
                  Colors.white),
              _buildStatItem(
                  'Remaining Available',
                  '$currency ${NumberFormat('#,##0').format(remainingBudget)}',
                  remainingBudget >= 0 ? Colors.greenAccent : Colors.redAccent),
              _buildStatItem(
                  'Spent',
                  '$currency ${NumberFormat('#,##0').format(totalSpent)}',
                  Colors.redAccent),
              _buildStatItem(
                  'Total Budget Utilised',
                  '${budgetUsagePercentage.toStringAsFixed(0)}%',
                  Colors.orangeAccent),
            ],
          ),
          SizedBox(height: 24.h),
          Center(
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 120.w,
                  height: 120.w,
                  child: CircularProgressIndicator(
                    value: (budgetUsagePercentage / 100).clamp(0.0, 1.0),
                    strokeWidth: 8.w,
                    backgroundColor: Colors.white.withOpacity(0.3),
                    valueColor: AlwaysStoppedAnimation<Color>(
                      budgetUsagePercentage > 100
                          ? Colors.red
                          : budgetUsagePercentage > 80
                              ? Colors.orange
                              : Colors.white,
                    ),
                  ),
                ),
                Column(
                  children: [
                    Text(
                      '${budgetUsagePercentage.toStringAsFixed(0)}%',
                      style: TextStyle(
                        fontSize: 24.sp,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'Used',
                      style: TextStyle(
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w500,
                        color: Colors.white.withOpacity(0.8),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12.sp,
            fontWeight: FontWeight.w500,
            color: Colors.white.withOpacity(0.8),
          ),
        ),
        SizedBox(height: 4.h),
        Text(
          value,
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
      ],
    );
  }
}
